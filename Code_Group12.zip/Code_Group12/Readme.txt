================================Read Me==============================================

We have not implemented building of the project from the command line- with a 
makefile for instance; however, if one runs "Main.cpp" in a C++ compiler while "Main.cpp" is in the 
same folder as the rest of the files extracted from this zipped folder; it should build and run fine. 
Preferably this should be done in VS Studio or an equivalent as that was the IDE in which we did 
all of this.


There indeed seemingly duplicates of the .csv files; however, there are minute differences
bwteen them that we didn't have time to reconicle our respective paths with.